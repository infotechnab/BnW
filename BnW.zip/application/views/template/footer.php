<footer>
    <!-- Container -->
    <div class="container">
        <!-- Footer Content -->
        <!-- Paragraph -->
        <p class="pull-left">Copyright &copy; 2015 - <a href="#">BnW</a></p>
        <ul class="list-inline pull-right">
            <!-- List -->
            <li><a href="#">Home</a></li><li>
            </li><li><a href="#">Service</a></li>
            <li><a href="#">Features</a></li>
            <li><a href="#">About</a></li>
            <li><a href="#">Contact</a></li>
        </ul>
        <!-- Clearfix -->
        <div class="clearfix"></div>
    </div>
</footer>