<div id="home-page-mail" class="pad-section">
 <!-- third section - Services -->
<div id="services-facility-inner-div-back">
	  
                <h1 id="services-facility-heading-first">Services & Facilities</h1>
	     
                <div class="left-services-div">
                   <li class="list-group-item list-group-item-primary active" data-checked="true" style="cursor: pointer;">
                        <span class="state-icon glyphicon glyphicon-check"></span>
                        <h4 style="display: inline-block;">Air- conditioned rooms</h4>
                             <input class="hidden" type="checkbox">
                    </li><br/>
                    <li class="list-group-item list-group-item-primary active" data-checked="true" style="cursor: pointer;">
                        <span class="state-icon glyphicon glyphicon-check"></span>
                        <h4 style="display: inline-block;">Mini Bars</h4>
                             <input class="hidden" type="checkbox">
                    </li><br/>
                    <li class="list-group-item list-group-item-primary active" data-checked="true" style="cursor: pointer;">
                        <span class="state-icon glyphicon glyphicon-check"></span>
                        <h4 style="display: inline-block;">Package tours</h4>
                             <input class="hidden" type="checkbox">
                    </li><br/>
                    <li class="list-group-item list-group-item-primary active" data-checked="true" style="cursor: pointer;">
                        <span class="state-icon glyphicon glyphicon-check"></span>
                        <h4 style="display: inline-block;">Free Wi-Fi access</h4> 
                             <input class="hidden" type="checkbox">
                    </li>
                </div>
                
                <div class="left-services-div">
                   <li class="list-group-item list-group-item-primary active" data-checked="true" style="cursor: pointer;">
                        <span class="state-icon glyphicon glyphicon-check"></span>
                        <h4 style="display: inline-block;">In room dining</h4>
                             <input class="hidden" type="checkbox">
                    </li><br/>
                    <li class="list-group-item list-group-item-primary active" data-checked="true" style="cursor: pointer;">
                        <span class="state-icon glyphicon glyphicon-check"></span>
                        <h4 style="display: inline-block;">32" LED television with multiple channels</h4>
                             <input class="hidden" type="checkbox">
                    </li><br/>
                    <li class="list-group-item list-group-item-primary active" data-checked="true" style="cursor: pointer;">
                        <span class="state-icon glyphicon glyphicon-check"></span>
                        <h4 style="display: inline-block;">Outdoor swimming pool</h4>
                             <input class="hidden" type="checkbox">
                    </li><br/>
                    <li class="list-group-item list-group-item-primary active" data-checked="true" style="cursor: pointer;">
                        <span class="state-icon glyphicon glyphicon-check"></span>
                        <h4 style="display: inline-block;">Laundry services</h4> 
                             <input class="hidden" type="checkbox">
                    </li> 
                </div>
	    
	</div> 
    
</div>