<div class="container" style="min-height: 300px;padding-top: 50px;">
    <div class="row">
        <div class="col-md-12 text-center">
            <div class="error-template">
                <h1>
                    Oops!</h1>
                <h2>
                    Page Not Found</h2>
                <div class="error-details">
                    Sorry, an error has occured, the page you requested is not found!
                </div>
                <div class="error-actions">
                    <a href="<?php echo base_url(); ?>" class="btn btn-primary btn-lg"><i class="fa fa-home"></i>
                        Take Me Home </a>
                </div>
            </div>
        </div>
    </div>
</div>