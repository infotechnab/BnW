</div><div class="clear"></div>
<div id="footer">
            

<!--<p>© Copy right to Smart Access Service.

Powered by BnW CMS.
</p>-->
        </div>
       
</body>
</html>