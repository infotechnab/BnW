<style>.breadcrumb {
    background: #ddd none no-repeat scroll 50% 50% / cover ;
    border-radius: 0;
    display: inline-block;
    font-size: 13px;
    margin: -3px 0 0;
    padding: 0;
    position: relative;
}</style><header id="page-title">
				<div class="container">
					<h1><?php echo $pageTitle; ?></h1>

					<ul class="breadcrumb">
						<?php echo $link; ?>
					</ul>
				</div>
			</header>