<div class="rightSide">
    <div class="">
        <div class="">
            <div class="">
                <h1>
                    Oops!</h1>
                <h2>
                    You cannot delete this user. It is current logged in.</h2>
                
            </div>
        </div>
    </div>
</div>