<div class="leftSide">
            <div class="menuItems">
                <ul class="menu">
                        <li class="mainMenuItem"> <a href="#">Dashboard</a>
                        <ul class="subMenu">                            
                            <li><?php echo anchor('bnw', 'Home') ?></li>
                            <li><?php echo anchor('dashboard/addmenu', 'Add Menu') ?></li>
                            <li><?php echo anchor('dashboard/navigation', 'Navigation') ?></li>
                            <li><?php echo anchor('dashboard/category', 'Categories') ?></li>
                        </ul>
                    </li>
                    
<!--                    <li class="mainMenuItem"> <a href="#">Product</a>
                        <ul class="subMenu">
                            <li><?php //echo anchor('bnw/product', 'Add New Product') ?></li>
                            <li><?php //echo anchor('bnw/productList', 'Products') ?></li>
                           <li><?php //echo anchor('bnw/disproduct', 'Sold Info') ?></li>
                            <li><?php //echo anchor('bnw/productShipping', 'Shipping ') ?></li>
                            <li><?php //echo anchor('bnw/coupon', 'Create Coupon ') ?></li>
                            
                        </ul>
                    </li>-->
                    <li class="mainMenuItem"><a href="#">Events</a>
                        <ul class="subMenu">
                            <li><?php echo anchor('events/event', 'All Event') ?></li>
                            <li><?php echo anchor('events/addevent', 'Add New Event') ?></li>
                        </ul>
                    </li>
                    <li class="mainMenuItem"><a href="#">Posts</a>
                        <ul class="subMenu">
                            <li><?php echo anchor('offers/posts', 'All Posts') ?></li>
                            <li><?php echo anchor('offers/addpost', 'Add New Post') ?></li>
                        </ul>
                    </li>
                    <li class="mainMenuItem"><a href="#">Pages</a>
                        <ul class="subMenu">
                            <li><?php echo anchor('page/pages', 'All Pages') ?></li>
                            <li><?php echo anchor('page/addpage', 'Add New') ?></li>                            
                        </ul>
                    </li>
                    <li class="mainMenuItem"><a href="#">Users</a>
                        <ul class="subMenu">
                            <li><?php echo anchor('user/adduser', 'Add New') ?></li>
                            <li><?php echo anchor('user/users', 'All Users') ?></li>
                            <li><?php echo anchor('user/profile', 'My Profile') ?></li>
                        </ul>
                    </li>
                   <li class="mainMenuItem"><a href="#">Media</a>
                        <ul class="subMenu">
                            <li><?php echo anchor('album/media', 'Library') ?></li>
                            <li><?php echo anchor('album/addmedia', 'Add New') ?></li>                           
                        </ul>
                    </li>
                    <li class="mainMenuItem"><a href="#">Social Share</a>
                        <ul class="subMenu">
                            <li><?php echo anchor('social_share', 'Accounts') ?></li>
                            
                        </ul>
                    </li>
                    <li class="mainMenuItem"><a href="#">Settings</a>
                        <ul class="subMenu">
                            <li><?php echo anchor('setting/header', 'Header') ?></li>
                            <li><?php echo anchor('setting/sidebar', 'Sidebar') ?></li>
                            <li><?php echo anchor('setting/miscsetting', 'Miscellaneous Setting') ?></li>
                            <li><?php echo anchor('gadgets', 'Gadgets') ?></li> 
                            
                            <li><?php echo anchor('setting/setup', 'Setup') ?></li>
                        </ul>
                    </li>
                    
                   
                    <li class="mainMenuItem"><a href="#">Album</a>
                        <ul class="subMenu">
                            <li><?php echo anchor('album/addalbum', 'Add New') ?></li>
                            
                        </ul>
                    </li>
                    
                    <li class="mainMenuItem"><a href="#">Slider</a>
                        <ul class="subMenu">
                            <li><?php echo anchor('sliders/addslider', 'Add New') ?></li>
                            <li><?php echo anchor('sliders/slider', 'View All Slider') ?></li>
                        </ul>
                    </li>       
                    
                    <li class="mainMenuItem"><a href="#">Subscriber</a>
                        <ul class="subMenu">
                            <li><?php echo anchor('subscribers/viewSubscriber', 'Newsletter subscriber') ?></li>
                            <li><?php echo anchor('subscribers/viewContact', 'Contact List') ?></li>
                        </ul>
                    </li>
                    <li class="mainMenuItem"><a href="#">Contact Form</a>
                        <ul class="subMenu">
                            <li><?php echo anchor('contact/updateContact', 'Contact Form') ?></li>
                            
                        </ul>
                    </li>
                   
               </ul>   
                
            </div>
    <div id="bnwcredit">
        <p>&COPY; Copy right to B&W......</p><p> Powered by BnW CMS.</p>
    </div>
    
    
        </div>
        
        
        <!left side is cleared and closed here>
        