<?php 

    function recent_post()
    {
        $recentPost[]=array('noOfPost' => 'text','titleBold' => 'checkbox','titleUnderline' => 'checkbox','titleColor' => 'color');
        return $recentPost;
       
    }
