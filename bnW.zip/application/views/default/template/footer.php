<footer>
    <!-- Container -->
    <div class="container">
        <!-- Footer Content -->
        <!-- Paragraph -->
        <p class="pull-left">Copyright &copy; 2015 - All rights reserved</p>
        
        <ul class="list-inline pull-right">
            <!-- List -->
            <li>Powered by BnW.</li>
            <li>Design by <a href="#">SALYANI</a></li>
        </ul>
        
        
        <div class="clearfix"></div>
    </div>
</footer>