<div class="blue-bg">
            <div class="container">
                <div class="row">
                    <div class="col-sm-6 margin30">
                        <div class="services-box wow animated fadeInDown animated" style="visibility: visible; animation-name: fadeInDown;">
                            <div class="services-box-icon">
                                <i class="fa fa-bars"></i>
                            </div><!--services icon-->
                            <div class="services-box-info">
                                <h4>10 + menu Items</h4>
                                <p>
                                    BnW covers almost all menu items needed for a complete business website.</p></div>
                        </div><!--service box-->
                    </div>
                    <div class="col-sm-6 ">
                        <div class="services-box wow animated fadeInUp animated" style="visibility: visible; animation-name: fadeInUp;">
                            <div class="services-box-icon">
                                <i class="fa fa-download"></i>
                            </div><!--services icon-->
                            <div class="services-box-info">
                                <h4>Free Support &amp; Updates</h4>
                                <p>
                                    You can get free update and support in this CMS from highly skilled and qualified software engineers. </p></div>
                        </div><!--service box-->
                    </div>
                </div>
            </div>
        </div>