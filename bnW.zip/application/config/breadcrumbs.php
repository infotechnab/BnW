<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$config['tag_open'] = '<ol class="breadcrumb breadcrumb-red">';
$config['tag_close'] = '</ol>';
$config['crumb_open'] = '<li>';
$config['crumb_last_open'] = '<li class="active">';
$config['crumb_close'] = '</li>';

