$(document).ready(function(){
    $(document).on("click",".del_category",function(){
        
    });
});