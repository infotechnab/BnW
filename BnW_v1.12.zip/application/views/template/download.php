<div id='download'><div class='container'>
        <div class='row'>
            <div class="cta-one">
                <!-- CTA One Content -->
                <div class="cta-one-content">
                    <div class="row">
                        <div class="col-md-5">
                            <!-- CTA One Item -->
                            <div class="cta-one-item">
                                <h4 style='margin-top: 0px;'>A Complete CMS, that you are looking for.</h4>
                                <p>BnW is a MVC CMS developed from Chitwan. The motto of this is to make content management and web production easy, fast, reliable and convenient.</p>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="cta-one-item">
                                <ul class="list-2">
                                    <li>Easy To Use</li>
                                    <li>Easy To Add and Update Contents</li>
                                    <li>Responsive Designs</li>
                                    <li>24 7 Service</li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <a class="btn btn-color btn-lg" href="<?php echo base_url().'index.php/demo/download'; ?>"><i class="fa fa-download"></i>&nbsp; Download Now</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>