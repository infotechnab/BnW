 <!--subscribe newsletters-->
    <div class="newsletter">  
        <div style="margin: 0px auto;width:80%;">
        <h1 style="color: #fff;font-weight: 300;font-size: 50px;text-transform: uppercase;padding: 0% 2% 2% 2%;width: 80%;text-align: center;font-family: 'Lato',Calibri,Arial,sans-serif;letter-spacing: normal;">SUBSCRIBE TO OUR NEWSLETTER</h1>
        <div><input type="text" placeholder="Name" style="width: 300px"> <input type="text" placeholder="E-mail Address"> <input type="button" value="Subscribe"></div>
        </div>
    </div>
