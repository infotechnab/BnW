
<div class="footer">
     <?php for($i=0;$i<3;$i++) {?>
    <div class="box footer_box"> 
        <div class="footer_heading">HEADING</div>
        <div class="footer_content">
            
                FLTDSGN IS A SHOWCASE OF SOME OF 
                THE BEST EXAMPLES OF WEB DESIGN USING 
                THE FLAT UI STYLE/AESTHETIC. 

            
        </div>
    </div>
    <?php } ?>
    <div class="clear"></div>
    
    <div class="copyright">© 2002-2014 Bluehost Inc. All rights reserved.<br>
*The promotional price is for the first term only and renews at the regular rate</div>
</div> 

</div>

</body>
</html>