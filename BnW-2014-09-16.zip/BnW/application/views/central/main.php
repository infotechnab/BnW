   <div id="myCarousel" class="carousel slide" style="margin-top: 10px;">
            

          <div class="carousel-inner">  
        <?php foreach($slidequery as $sliderimg) { ?>
           <div class="item">
             <img src="<?php echo base_url().'content/uploads/sliderImages/'.$sliderimg->slide_image; ?>" width="100%" height="100%">
          <div class="carousel-caption">
              <h3 style="color:#fff;"><?php echo $sliderimg->slide_name; ?></h3>
                 <p><?php echo $sliderimg->slide_content ?></p>
             </div>
         </div>
        <?php } ?>
  </div>    
  <a class="carousel-control left" href="#myCarousel" data-slide="prev">&lsaquo;</a>  
  <a class="carousel-control right" href="#myCarousel" data-slide="next">&rsaquo;</a>  
</div>  


    
    <script src="<?php echo base_url().'content/uploads/scripts/carousel.js'; ?>"></script>
    
  
    
    
    
    
    
    
    
    
    
    
    
    
    
    
 
   <div class="content">
  
        <div class="part">
            <div class="title">Study Abroad</div>
            <div class="circle"><img src="<?php echo base_url().'content/uploads/images/facilityImg/2.png' ?>" class="img-circle"></div>
            <div class="summary">Study Abroad in the australia and get certified from the world top university.</div>
            <div class="details"><span><b>View More </b>&rsaquo;&rsaquo;</span></div>
        </div>  
       
  
       
        <div class="part">
            <div class="title">Test Preparation</div>
            <div class="circle"><img src="<?php echo base_url().'content/uploads/images/facilityImg/3.png' ?>" class="img-circle"></div>
            <div class="summary">Test preparation of various like IELTS, SAT, GRE with heighest score and from the most experienced teacher.</div>
            <div class="details"><span><b>View More </b>&rsaquo;&rsaquo;</span></div>
        </div>
       
        <div class="part">
            <div class="title">Computer Courses</div>
            <div class="circle"><img src="<?php echo base_url().'content/uploads/images/facilityImg/4.png' ?>" class="img-circle"></div>
            <div class="summary">Get study of various courses related to computer with great pratical knowledge and offer to work in real life projects.</div>
            <div class="details"><span><b>View More </b>&rsaquo;&rsaquo;</span></div>
        </div>
       
       
       
    </div>
    <div class="clear"></div>
   
   
    
    <div class="arrow1"></div> 
    
    <!--sucess story-->
    <div class="sucess-story">
    <div class="sucess-story-title">Sucessful Story</div>
      <?php foreach($postquery as $sucess) { ?>
    <div class="sucess-story-content">
      
        <div><img src="<?php echo base_url().'content/uploads/images/'.$sucess->image; ?>" height="200" width="150"></div>
        <div style="font-size: 12px;font-weight: bolder;color:#000;text-align: center; "><?php echo $sucess->post_title; ?></div>
        <div style="font-size: 12px;color:#990000;text-align: center;"><?php echo $sucess->post_content; ?></div>
    </div>
        <?php } ?>
    <div class="clear"></div>
    <div style="font-size: 16px;color: #fff;text-align: center;color:#fff;">
        <a href="<?php echo base_url().'index.php/view/sucess_story';?>" style="color: #fff;">
            <b>Sell All &rsaquo;&rsaquo;</b>
    <!--</a>-->
    </div>
       

    </div>
<div class="arrow"></div>


